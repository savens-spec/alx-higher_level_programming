# Python - Almost a circle
