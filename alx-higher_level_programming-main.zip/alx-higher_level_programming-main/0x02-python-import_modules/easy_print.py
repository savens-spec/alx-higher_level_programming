#!/usr/bin/python3
def easy_print():
    return("#pythoniscool\n")
