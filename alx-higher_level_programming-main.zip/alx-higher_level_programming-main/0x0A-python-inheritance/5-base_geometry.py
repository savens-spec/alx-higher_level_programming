#!/usr/bin/python3
"""Contains a `BaseGeometry` class"""


class BaseGeometry():
    """An empty class"""
    pass
