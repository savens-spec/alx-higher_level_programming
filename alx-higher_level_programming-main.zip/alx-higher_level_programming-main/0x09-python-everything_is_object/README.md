# Python - Everything is object
