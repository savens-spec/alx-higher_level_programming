#!/usr/bin/python3
def islower(i):
    if ord(i) >= ord('a') and ord(i) <= ord('z'):
        return True
    else:
        return False
