-- Lists all databases of my MySQL server.
SHOW DATABASES;
