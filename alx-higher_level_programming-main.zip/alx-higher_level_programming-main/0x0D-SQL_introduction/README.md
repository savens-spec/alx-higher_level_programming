# SQL - Introduction

In this project, we began working on relational databases.
